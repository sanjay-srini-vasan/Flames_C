#include<stdio.h>
#include<string.h>
int main()
{
    char str1[20],str2[20],str3[20],str4[7]={'F','L','A','M','E','S'};
    int a=0,e=0;
    char c;
    printf("enter the first person name:");
    scanf("%s",str1);
    printf("enter the seconf person name:");
    scanf("%s",str2);
    strcpy(str3,str2);
    int n1=strlen(str1);
    int n2=strlen(str2);
    int n=n1+n2;
    for(int i=0;i<n1;i++)
    {
        for(int j=0;j<n2;j++)
        {
            if(str1[i]==str2[j])
            {
                str2[j]='0';
                n=n-2;
                break;
            }
        }
    }
    printf("%d",n);
    int k=n*6;
    for(int i=0;a<k;i++)
    {
        if(str4[i]!='0')
        {
            a=a+1;
            if(a%n==0)
            {
                e=e+1;
                c=str4[i];
                if(e<6)
                {
                    str4[i]='0';
                }
            }
        }
         if(i==5)
         {
            i=-1;
         }
    }
    printf("\n%c",c);
    switch(c)
    {
        case 'F':
        {
            printf("FRIENDS FOREVER");
            break;
        }
        case 'L':
        {
            printf("LOVE FOREVER");
            break;
        }
        case 'A':
        {
            printf("ARRANGE MARRIAGE");
            break;
        }
        case 'M':
        {
            printf("MARRIAGE");
            break;
        }
        case 'E':
        {
            printf("ENEMY FOREVER");
            break;
        }
        case 'S':
        {
            printf("SISTER");
            break;
        }
    }
}